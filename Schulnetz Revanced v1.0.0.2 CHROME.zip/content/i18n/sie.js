/**
 * sie.js - Text-Ersetzungen für die formelle Form "Sie"
 */

window.REvanced_Translations_Sie = [
    { old: "schulNetz", new: "Schulnetz REvanced" },
    { old: "Willkommen im schulNetz.", new: "Willkommen im Schulnetz REvanced" },
    { old: "Ihre letzten Noten", new: "Ihre Notenübersicht" },
    { old: "Abmelden", new: "Sicher ausloggen" },
    { old: "Absenzen", new: "Fehlzeiten" },
        { old: "schulNetz App", new: "Schulnetz Revanced App - In Entwicklung" },
    { old: " Laden Sie die offizielle schulNetz App aus dem jeweiligen Store. Die App ist verfügbar auf:", new: "Schulnetz Revanced ist momentan nur im Browser verfügbar. Wir arbeiten an einer Mobile App 😉." }
];
