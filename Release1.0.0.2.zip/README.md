# SchulnetzREvanced
Schulnetz ist eine Plattform für Schulen. Da diese ein Refresh gut vertragen kann, gibt es hier das entsprechende Browser ADDON für besseren Style 😉
